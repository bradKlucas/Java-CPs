
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SaveTheBarns {
	//declare input variables
	static String iString, iName, iAddress, iCity, iState, iZip;
	static char iParty, iGender;
	static double iCont;
	
	//declare device variables
	static Scanner inputScan;
	static PrintWriter pw;
	static NumberFormat nfc;
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static String iDate = today.format(dtf);
	
	//declare program variables
	static String oMenCtr, oWomenCtr, oDemCtr, oRepCtr, oIndCtr, oRepMenCtr,
			oRepWomenCtr, oDemMenCtr, oDemWomenCtr, oIndMenCtr, oIndWomenCtr, oAvg, oTotal,
			oMenCont, oMenAvg, oWomenCont, oWomenAvg, oDemCont, oDemAvg, oRepCont, oRepAvg,
			oIndCont, oIndAvg, oDemMenCont, oDemMenAvg, oDemWomenCont, oDemWomenAvg, oRepMenCont,
			oRepMenAvg, oRepWomenCont, oRepWomenAvg, oIndMenCont, oIndMenAvg, oIndWomenCont,
			oIndWomenAvg, oTotalCont, oTotalAvg;
	
	static double cAvg, cMenCont = 0, cMenAvg, cWomenCont = 0, cWomenAvg, cRepCont = 0, cRepAvg,
			cDemCont = 0, cDemAvg, cIndCont = 0, cIndAvg, cTotalCont = 0, cTotalAvg, 
			cDemMenCont = 0, cDemMenAvg, cDemWomenCont = 0, cDemWomenAvg, cRepMenCont = 0, cRepMenAvg, cRepWomenCont = 0, cRepWomenAvg, 
			cIndMenCont = 0, cIndMenAvg, cIndWomenCont = 0, cIndWomenAvg;
			
	
	static int cTotal, menCtr = 0, womenCtr = 0, demCtr = 0, repCtr = 0, indCtr = 0, repMenCtr = 0,
			repWomenCtr = 0, demMenCtr = 0, demWomenCtr = 0, indMenCtr = 0, indWomenCtr = 0;
			
	static boolean eof = false;
			
			
	public static void main(String[] args) {
		//call init
		init();
		
		do {
			calc();
			input();
			validation();
			
		}while(!eof);
		
		//call final
		fincalc();
		output();
		pw.close();
	}
	
	public static void init() {
		
		nfc = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		//set up inputScan and Error message
		try {
			inputScan = new Scanner(new File("contributors.dat"));
			inputScan.useDelimiter(System.getProperty("line.separator"));
			
		}catch (FileNotFoundException e1) {
			System.out.println("File Error");
			System.exit(1);
		}
		//initial PrinterWriter
		try {
			pw = new PrintWriter(new File ("error.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
					
		//do init input
		input();
		validation();
		
	}
	
	public static void input() {
		String record;
		
		if (inputScan.hasNext()) {
			record = inputScan.next();
			
			iName = record.substring(0,25);	    //file position 1 - 25
		
			iAddress = record.substring(25,50);	    //file position 26 - 50
			
			iCity = record.substring(50,65);		//file position 51 - 65
			
			iState = record.substring(65,67);		//file position 66 - 67
			
			iZip = record.substring(67,72);		    //file position 68 - 72
				
			iString = record.substring(72,73);		//file position 73
			iParty = iString.charAt(0);
		
			iString = record.substring(73,74);		//file position 74
			iGender = iString.charAt(0);
			
			try {
				iString = record.substring(74,81);		//file position 75 - 81
				iCont = Double.parseDouble(iString);
			} catch(Exception e){
				pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Message");
			}	
		}
		else {
			eof = true;	
		}
	}

	
	public static void validation() {
		if (iName.trim().isEmpty()){
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Must have data within field");
		}
		
		if (iAddress.trim().isEmpty()){
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Must have data within field");
		}
		
		if (iCity.trim().isEmpty()){
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Must have data within field");
		}
		
		if (iState.trim().isEmpty()){
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Must have data within field");
		}
		
		int zipLength = iZip.length(); 
		if (zipLength!=5){
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Zip must be 5 characters");
		}
		
		if(iCont < .01 || iCont > 9999.99) {
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Contribution is out of range");
		}
	}
	
	public static void calc() {
		if(iGender == 'M' || iGender == 'm') {
			menCtr += 1;
			cMenCont += iCont;
			switch (iParty) {
			case 'D':
				demCtr += 1;
				demMenCtr += 1;
				cDemMenCont += iCont;
				break;
			case 'I':
				indCtr += 1;
				indMenCtr += 1;
				cIndMenCont += iCont;
				break;
			case 'R': 
				repCtr += 1;
				repMenCtr += 1;
				cRepMenCont += iCont;
				break;
			default:
				pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Party must be the following options: D, R, or I");
				break;
			}
			
		} else if(iGender == 'F' || iGender =='f') {
			womenCtr += 1;
			cWomenCont += iCont;
			switch (iParty) {
			case 'D':
				demCtr += 1;
				demWomenCtr += 1;
				cDemWomenCont += iCont;
				break;
			case 'I':
				indCtr += 1;
				indWomenCtr += 1;
				cIndWomenCont += iCont;
				break;
			case 'R': 
				repCtr += 1;
				repWomenCtr += 1;
				cRepWomenCont += iCont;
				break;
			default:
				pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Party must be the following options: D, R, or I");
				break;
			}
		} else {
			pw.format("%-81s%5s%56s%n", iName + iAddress + iCity + iState + iZip + iParty + iGender + iCont, " ", "Gender must be the following options: M or F");
		}
	}
	
	public static void fincalc() {
		cTotal = menCtr + womenCtr;

		cMenCont = cDemMenCont + cRepMenCont + cIndMenCont;
		cMenAvg = cMenCont / menCtr;
		
		cWomenCont = cDemWomenCont + cRepWomenCont + cIndWomenCont;
		cWomenAvg = cWomenCont / womenCtr;
		
		cRepCont = cRepMenCont + cRepWomenCont;
		cRepAvg = cRepCont / repCtr;
		
		cDemCont = cDemMenCont + cDemWomenCont;
		cDemAvg = cDemCont / demCtr;
		
		cIndCont = cIndMenCont + cIndWomenCont;
		cIndAvg = cIndCont / indCtr;
		
		cDemMenAvg = cDemMenCont / demMenCtr;
		cDemWomenAvg = cDemWomenCont / demWomenCtr;
		
		cRepMenAvg = cRepMenCont / repMenCtr;
		cRepWomenAvg = cRepWomenCont / repWomenCtr;
		
		cIndMenAvg = cIndMenCont / indMenCtr;
		cIndWomenAvg = cIndWomenCont / indWomenCtr;
		
		
		cTotalCont = cWomenCont + cMenCont;
		cTotalAvg = cTotalCont / cTotal;
		
	}
	
	public static void output() {
		//format
		oMenCtr = Integer.toString(menCtr);
		oMenCont = nfc.format(cMenCont);
		oMenAvg = nfc.format(cMenAvg);
		
		oWomenCtr = Integer.toString(womenCtr);
		oWomenCont = nfc.format(cWomenCont);
		oWomenAvg = nfc.format(cWomenAvg);
		
		oDemCtr = Integer.toString(demCtr);
		oDemCont = nfc.format(cDemCont);
		oDemAvg = nfc.format(cDemAvg);
		
		oRepCtr = Integer.toString(repCtr);
		oRepCont = nfc.format(cRepCont);
		oRepAvg = nfc.format(cRepAvg);
		
		oIndCtr = Integer.toString(indCtr);
		oIndCont = nfc.format(cIndCont);
		oIndAvg = nfc.format(cIndAvg);
	
		oDemMenCtr = Integer.toString(demMenCtr);
		oDemMenCont = nfc.format(cDemMenCont);
		oDemMenAvg = nfc.format(cDemMenAvg);
		
		oDemWomenCtr = Integer.toString(demWomenCtr);
		oDemWomenCont = nfc.format(cDemWomenCont);
		oDemWomenAvg = nfc.format(cDemWomenAvg);
		
		oRepMenCtr = Integer.toString(repMenCtr);
		oRepMenCont = nfc.format(cRepMenCont);
		oRepMenAvg = nfc.format(cRepMenAvg);
		
		oRepWomenCtr = Integer.toString(repWomenCtr);
		oRepWomenCont = nfc.format(cRepWomenCont);
		oRepWomenAvg = nfc.format(cRepWomenAvg);
		
		oIndMenCtr = Integer.toString(indMenCtr);
		oIndMenCont = nfc.format(cIndMenCont);
		oIndMenAvg = nfc.format(cIndMenAvg);
		
		oIndWomenCtr = Integer.toString(indWomenCtr);
		oIndWomenCont = nfc.format(cIndWomenCont);
		oIndWomenAvg = nfc.format(cIndWomenAvg);
		
		oTotal = Integer.toString(cTotal);
		oTotalCont = nfc.format(cTotalCont);
		oTotalAvg = nfc.format(cTotalAvg);
		
		//display records to console
		System.out.format("%-25s%16s%10s%20s%10s%n%n", "Freedom Barns", " ", "Summary Report", " ", iDate);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n%n", "Category", " ", "Count", " ", 
				"Total Contribution", " ", "Avg");
		
		System.out.format("%-3s%27s%10s%5s%25s%5s%10s%n", "Men", " ", oMenCtr, " ", 
				oMenCont, " ", oMenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Women", " ", oWomenCtr, " ", 
				oWomenCont, " ", oWomenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Democrats", " ", oDemCtr, " ", 
				oDemCont, " ", oDemAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Republican", " ", oRepCtr, " ", 
				oRepCont, " ", oRepAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Independents", " ", oIndCtr, " ", 
				oIndCont, " ", oIndAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Democratic Men", " ", oDemMenCtr, " ", 
				oDemMenCont, " ", oDemMenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Democratic Women", " ", oDemWomenCtr, " ", 
				oDemWomenCont, " ", oDemWomenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Republican Men", " ", oRepMenCtr, " ", 
				oRepMenCont, " ", oRepMenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Republican Women", " ", oRepWomenCtr, " ", 
				oRepWomenCont, " ", oRepWomenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Independent Men", " ", oIndMenCtr, " ", 
				oIndMenCont, " ", oIndMenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Independent Women", " ", oIndWomenCtr, " ", 
				oIndWomenCont, " ", oIndWomenAvg);
		
		System.out.format("%-25s%5s%10s%5s%25s%5s%10s%n", "Overall", " ", oTotal, " ", 
				oTotalCont, " ", oTotalAvg);
		
	}
}

