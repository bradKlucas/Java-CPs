/* Created by Brad Klucas 
 * Compiled on 1/28/19
 * 
 * this programs reads in an input file and calculates a record counter, accumulator and avg
 *  then the program outputs a summary report
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SummaryReport {
	//input/output vars
	static String iStudentID, iGender, iMjCode, hMjCode, iDonation, oStudentID, oGender, oMjDonation, oRecCtr, oMjCode, oDonation, oGtRecCtr, oGtDonation;
	
	//calc vars
	static double cDonation, cMjDonation = 0, cGtDonation = 0, cMaleITDonation = 0, cMaleMTDonation = 0, cMaleTTDonation = 0, cFemaleITDonation = 0, cFemaleMTDonation = 0, cFemaleTTDonation = 0
			,cMaleDonation = 0, cFemaleDonation = 0, cMaleAvg, cFemaleAvg, cITAvg, cMTAvg, cTTAvg, cITDonation, cMTDonation, cTTDonation, cOverallAvg, cOverallDonation, cMaleITAvg, cFemaleITAvg,
			cMaleMTAvg, cFemaleMTAvg, cMaleTTAvg, cFemaleTTAvg; 
	//counters
	static int cMaleITCtr = 0, cMaleMTCtr = 0, cMaleTTCtr = 0,
			cFemaleITCtr = 0, cFemaleMTCtr = 0, cFemaleTTCtr = 0, cITCtr = 0, cMTCtr = 0, cTTCtr = 0, cOverallCtr, cMaleTotal, cFemaleTotal;
	static String oMaleCtr, oMaleITCtr, oMaleMTCtr, oMaleTTCtr, oFemaleCtr, 
			oFemaleITCtr, oFemaleMTCtr, oFemaleTTCtr, oITCtr, oMTCtr, oTTCtr, oOverallCtr, oOverallAvg, oOverallDonation, oMaleDonation, oFemaleDonation, oITDonation, oMTDonation
			, oTTDonation, oMaleAvg, oFemaleAvg, oITAvg, oMTAvg, oTTAvg, oMaleTotal, oFemaleTotal, oMaleITAvg, oFemaleITAvg,
			oMaleMTAvg, oFemaleMTAvg, oMaleTTAvg, oFemaleTTAvg, oMaleITDonation, oFemaleITDonation, oMaleMTDonation, oFemaleMTDonation, oMaleTTDonation, oFemaleTTDonation;
	
	static boolean eof = false;
	//program vars
	static Scanner inputScan;
	static PrintWriter pw;
	static NumberFormat nfc;
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static String iDate = today.format(dtf);
	
	public static void main(String[] args) {
		init();
		do {
			calc();
			input();
			
		}while(!eof);
		fincalc();
		output();
		closing();
		
		
			
	}
	public static void init() {
		nfc = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		//set up inputScan and Error message
		try {
			inputScan = new Scanner(new File("IHCCFUND.dat"));
			inputScan.useDelimiter(System.getProperty("line.separator"));
			
		}catch (FileNotFoundException e1) {
			System.out.println("Input file error");
			System.exit(1);
		}
		//initial PrinterWriter
		try {
			pw = new PrintWriter(new File ("summary.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		heading();
		input();
	}
	public static void input() {
		String record;
		
		if (inputScan.hasNext()) {
			
			record = inputScan.next();
			
			iStudentID = record.substring(0,7);	    //file position 1 - 7
		
			iGender = record.substring(7,8);	    //file position 8 - 8
			
			iMjCode = record.substring(8,10);		//file position 9 - 10
			
			iDonation = record.substring(10,17);	//file position 10 - 17	
			cDonation = Double.parseDouble(iDonation);		
		}
		else {
		eof = true;
		}
	}
	public static void calc() {
		if (cDonation > 500) {
			if (iGender.equals("M")){
				oGender = "Male";
				
				switch(iMjCode) {
				case "01":
					oMjCode = "COMPUTER SOFTWARE DEVELOPMENT";
					cMaleITCtr += 1;
					cITCtr += 1;
					cMaleITDonation += cDonation;
					break;
				case "02":
					oMjCode = "DIESEL POWER SYSTEMS TECHNOLOGY";
					cMaleTTCtr += 1;
					cTTCtr += 1;
					cMaleTTDonation += cDonation;
					break;
				case "03":
					oMjCode = "AUTOMOTIVE TECHNOLOGY";
					cMaleTTCtr += 1;
					cTTCtr += 1;
					cMaleTTDonation += cDonation;
					break;
				case "04":
					oMjCode = "LASER/ELECTRO-OPTICS TECHNOLOGY";
					cMaleMTCtr += 1;
					cMTCtr += 1;
					cMaleMTDonation += cDonation;
					break;
				case "05":
					oMjCode = "ROBOTICS/AUTOMATION TECHNOLOGY";
					cMaleMTCtr += 1;
					cMTCtr += 1;
					cMaleMTDonation += cDonation;
					break;
				case "06":
					oMjCode = "DIGITAL FORENSICS";
					cMaleITCtr += 1;
					cITCtr += 1;
					cMaleITDonation += cDonation;
					break;
				case "07":
					oMjCode = "MACHINE TECHNOLOGY";
					cMaleMTCtr += 1;
					cMTCtr += 1;
					cMaleMTDonation += cDonation;
					break;
				case "08":
					oMjCode = "GEOSPATIAL TECHNOLOGY";
					cMaleITCtr += 1;
					cITCtr += 1;
					cMaleITDonation += cDonation;
					break;
				case "09":
					oMjCode = "ADMINISTRATIVE ASSISTANT";
					cMaleITCtr += 1;
					cITCtr += 1;
					cMaleITDonation += cDonation;
					break;
				case "10":
					oMjCode = "ACCOUNTING ASSISTANT";
					cMaleITCtr += 1;
					cITCtr += 1;
					cMaleITDonation += cDonation;
					break;
				case "11":
					oMjCode = "WELDING TECHNOLOGY";
					cMaleMTCtr += 1;
					cMTCtr += 1;
					cMaleMTDonation += cDonation;
					break;
				case "12":
					oMjCode = "AUTOMOTIVE COLLISION TECHNOLOGY";
					cMaleTTCtr += 1;
					cTTCtr += 1;
					cMaleTTDonation += cDonation;
					break;
				case "13":
					oMjCode = "AVAIATION PILOT TRAINING";
					cMaleTTCtr += 1;
					cTTCtr += 1;
					cMaleTTDonation += cDonation;
					break;
				}
			}
			else {
				oGender = "Female";
				
				switch(iMjCode) {
				case "01":
					oMjCode = "COMPUTER SOFTWARE DEVELOPMENT";
					cFemaleITCtr += 1;
					cITCtr += 1;
					cFemaleITDonation += cDonation;
					break;
				case "02":
					oMjCode = "DIESEL POWER SYSTEMS TECHNOLOGY";
					cFemaleTTCtr += 1;
					cTTCtr += 1;
					cFemaleTTDonation += cDonation;
					break;
				case "03":
					oMjCode = "AUTOMOTIVE TECHNOLOGY";
					cFemaleTTCtr += 1;
					cTTCtr += 1;
					cFemaleTTDonation += cDonation;
					break;
				case "04":
					oMjCode = "LASER/ELECTRO-OPTICS TECHNOLOGY";
					cFemaleMTCtr += 1;
					cMTCtr += 1;
					cFemaleMTDonation += cDonation;
					break;
				case "05":
					oMjCode = "ROBOTICS/AUTOMATION TECHNOLOGY";
					cFemaleMTCtr += 1;
					cMTCtr += 1;
					cFemaleMTDonation += cDonation;
					break;
				case "06":
					oMjCode = "DIGITAL FORENSICS";
					cMaleITCtr += 1;
					cITCtr += 1;
					cFemaleITDonation += cDonation;
					break;
				case "07":
					oMjCode = "MACHINE TECHNOLOGY";
					cFemaleMTCtr += 1;
					cMTCtr += 1;
					cFemaleMTDonation += cDonation;
					break;
				case "08":
					oMjCode = "GEOSPATIAL TECHNOLOGY";
					cFemaleITCtr += 1;
					cITCtr += 1;
					cFemaleITDonation += cDonation;
					break;
				case "09":
					oMjCode = "ADMINISTRATIVE ASSISTANT";
					cFemaleITCtr += 1;
					cITCtr += 1;
					cFemaleITDonation += cDonation;
					break;
				case "10":
					oMjCode = "ACCOUNTING ASSISTANT";
					cFemaleITCtr += 1;
					cITCtr += 1;
					cFemaleITDonation += cDonation;
					break;
				case "11":
					oMjCode = "WELDING TECHNOLOGY";
					cFemaleMTCtr += 1;
					cMTCtr += 1;
					cFemaleMTDonation += cDonation;
					break;
				case "12":
					oMjCode = "AUTOMOTIVE COLLISION TECHNOLOGY";
					cFemaleTTCtr += 1;
					cTTCtr += 1;
					cFemaleTTDonation += cDonation;
					break;
				case "13":
					oMjCode = "AVAIATION PILOT TRAINING";
					cFemaleTTCtr += 1;
					cTTCtr += 1;
					cFemaleTTDonation += cDonation;
					break;
				}
			}
		}else {
			input();
		}
		
		
	}
	public static void fincalc() {
		cMaleTotal = cMaleITCtr + cMaleMTCtr + cMaleTTCtr;
		cFemaleTotal = cFemaleITCtr + cFemaleMTCtr + cFemaleTTCtr;
		
		cMaleDonation = cMaleITDonation + cMaleMTDonation + cMaleTTDonation;
		cMaleAvg = cMaleDonation / cMaleTotal;
		
		cFemaleDonation = cFemaleITDonation + cFemaleMTDonation + cFemaleTTDonation;
		cFemaleAvg = cFemaleDonation / cFemaleTotal;
		
		cITDonation = cMaleITDonation + cFemaleITDonation;
		cITAvg = cITDonation / (cMaleITCtr + cFemaleITCtr);
		cMaleITAvg = cMaleITDonation / cMaleITCtr;
		cFemaleITAvg = cFemaleITDonation / cFemaleITCtr;
		
		cMTDonation = cMaleMTDonation + cFemaleMTDonation;
		cMTAvg = cMTDonation / (cMaleMTCtr + cFemaleMTCtr);
		cMaleMTAvg = cMaleMTDonation / cMaleMTCtr;
		cFemaleMTAvg = cFemaleMTDonation / cFemaleMTCtr;
		
		cTTDonation = cMaleTTDonation + cFemaleTTDonation;
		cTTAvg = cTTDonation / (cMaleTTCtr + cFemaleTTCtr);
		cMaleTTAvg = cMaleTTDonation / cMaleTTCtr;
		cFemaleTTAvg = cFemaleTTDonation / cFemaleTTCtr;
		
		cOverallCtr = cMaleTotal + cFemaleTotal;
		cOverallDonation = cMaleDonation + cFemaleDonation;
		cOverallAvg = cOverallDonation / cOverallCtr;
		
	}
	public static void output() {
		//format
		oMaleTotal = Integer.toString(cMaleTotal);
		oMaleDonation = nfc.format(cMaleDonation);
		oMaleAvg = nfc.format(cMaleAvg);
		
		oFemaleTotal = Integer.toString(cFemaleTotal);
		oFemaleDonation = nfc.format(cFemaleDonation);
		oFemaleAvg = nfc.format(cFemaleAvg);
		
		oITCtr = Integer.toString(cITCtr);
		oITDonation = nfc.format(cITDonation);
		oITAvg = nfc.format(cITAvg);
		
		oMTCtr = Integer.toString(cMTCtr);
		oMTDonation = nfc.format(cMTDonation);
		oMTAvg = nfc.format(cMTAvg);
		
		
		oTTCtr = Integer.toString(cTTCtr);
		oTTDonation = nfc.format(cTTDonation);
		oTTAvg = nfc.format(cTTAvg);
		
		oMaleITCtr = Integer.toString(cMaleITCtr);
		oMaleITDonation = nfc.format(cMaleITDonation);
		oMaleITAvg = nfc.format(cMaleITAvg);
		
		oMaleMTCtr = Integer.toString(cMaleMTCtr);
		oMaleMTDonation = nfc.format(cMaleMTDonation);
		oMaleMTAvg = nfc.format(cMaleMTAvg);
		
		oMaleTTCtr = Integer.toString(cMaleTTCtr);
		oMaleTTDonation = nfc.format(cMaleTTDonation);
		oMaleTTAvg = nfc.format(cMaleTTAvg);
		
		
		oFemaleITCtr = Integer.toString(cFemaleITCtr);
		oFemaleITDonation = nfc.format(cFemaleITDonation);
		oFemaleITAvg = nfc.format(cFemaleITAvg);
		
		oFemaleITCtr = Integer.toString(cFemaleITCtr);
		oFemaleITDonation = nfc.format(cFemaleITDonation);
		oFemaleITAvg = nfc.format(cFemaleITAvg);
		
		oFemaleITCtr = Integer.toString(cFemaleITCtr);
		oFemaleITDonation = nfc.format(cFemaleITDonation);
		oFemaleITAvg = nfc.format(cFemaleITAvg);
		
		oOverallCtr = Integer.toString(cOverallCtr);
		oOverallDonation = nfc.format(cOverallDonation);
		oOverallAvg = nfc.format(cOverallAvg);
		
		
		//print summary
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Male", " ", oMaleTotal, " ", oMaleDonation, " ", oMaleAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Female", " ", oFemaleTotal, " ", oFemaleDonation, " ", oFemaleAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Information Technology", " ", oITCtr, " ", oITDonation, " ", oITAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Manufacturing Technology", " ", oMTCtr, " ", oMTDonation, " ", oMTAvg); //132
		
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Transportation Technology", " ", oTTCtr, " ", oTTDonation, " ", oTTAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Male Information Technology", " ", oMaleITCtr, " ", oMaleITDonation, " ", oMaleITAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Female Information Technology", " ", oFemaleITCtr, " ", oFemaleITDonation, " ", oFemaleITAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Male Manufacturing Technology", " ", oMaleMTCtr, " ", oMaleMTDonation, " ", oMaleMTAvg); //132
		
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Female Manufacturing Technology", " ", oFemaleMTCtr, " ", oFemaleMTDonation, " ", oFemaleMTAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Male Transportation Technology", " ", oMaleTTCtr, " ", oMaleTTDonation, " ", oMaleTTAvg); //132
		pw.format("%-32s %11s %3s %32s %8s %29s %8s %n", "Female Transportation Technology", " ", oFemaleTTCtr, " ", oFemaleTTDonation, " ", oFemaleTTAvg); //132
		pw.format("%-32s %11s %3s %30s %12s %28s %10s %n", "Overall", " ", oOverallCtr, " ", oOverallDonation, " ", oOverallAvg); //132
	
	
	}
	public static void closing() {
		pw.close();
		System.out.println("Success! Please look at 'summary.prt' for results");
	}
	public static void heading() {
		//print company program title
		pw.format("%30s%29s%15s%42s%6s%10s%n%n","Indian Hills Community College", " ", "Subtotal Report", " ", "Date: ", iDate); //132
		pw.format("%8s %33s %5s %34s %8s %30s %8s %n%n", "Category", " ", "Count", " ", "Donation", " ", "Avgerage"); //132
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

