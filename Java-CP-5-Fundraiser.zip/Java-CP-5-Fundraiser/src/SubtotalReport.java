/* Created by Brad Klucas 
 * Compiled on 1/28/19
 * 
 * this programs reads in an input file and breaks the records into subtotal
 *  then the program outputs a subtotal report
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SubtotalReport {
	static String iStudentID, iGender, iMjCode, hMjCode, iDonation, oStudentID, oGender, oMjDonation, oRecCtr, oMjCode, oDonation, oGtRecCtr, oGtDonation;
	static int cRecCtr = 0, cGtRecCtr = 0;
	static double cDonation, cMjDonation = 0, cGtDonation = 0;
	
	static boolean eof = false;
	
	static Scanner inputScan;
	static PrintWriter pw;
	static NumberFormat nfc;
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static String iDate = today.format(dtf);
	
	public static void main(String[] args) {
		init();
		do {
			if (!hMjCode.equals(iMjCode)) {
				mjsub();
			}
			calc();
			output();
			input();
			
		}while(!eof);
		closing();
		
		
			
	}
	public static void init() {
		nfc = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		//set up inputScan and Error message
		try {
			inputScan = new Scanner(new File("IHCCFUND.dat"));
			inputScan.useDelimiter(System.getProperty("line.separator"));
			
		}catch (FileNotFoundException e1) {
			System.out.println("Input file error");
			System.exit(1);
		}
		//initial PrinterWriter
		try {
			pw = new PrintWriter(new File ("subtotal.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}
		
		//do init input
		heading();
		input();
		hMjCode = iMjCode;
	}
	public static void input() {
		String record;
		
		if (inputScan.hasNext()) {
			
			record = inputScan.next();
			
			iStudentID = record.substring(0,7);	    //file position 1 - 7
		
			iGender = record.substring(7,8);	    //file position 8 - 8
			
			iMjCode = record.substring(8,10);		//file position 9 - 10
			
			iDonation = record.substring(10,17);	//file position 10 - 17	
			cDonation = Double.parseDouble(iDonation);		
		}
		else {
		eof = true;
		}
		
		
		
	}
	public static void calc() {
		cRecCtr += 1;
		cMjDonation += cDonation;
		
		
		switch(iMjCode) {
		case "01":
			oMjCode = "COMPUTER SOFTWARE DEVELOPMENT";
			break;
		case "02":
			oMjCode = "DIESEL POWER SYSTEMS TECHNOLOGY";
			break;
		case "03":
			oMjCode = "AUTOMOTIVE TECHNOLOGY";
			break;
		case "04":
			oMjCode = "LASER/ELECTRO-OPTICS TECHNOLOGY";
			break;
		case "05":
			oMjCode = "ROBOTICS/AUTOMATION TECHNOLOGY";
			break;
		case "06":
			oMjCode = "DIGITAL FORENSICS";
			break;
		case "07":
			oMjCode = "MACHINE TECHNOLOGY";
			break;
		case "08":
			oMjCode = "GEOSPATIAL TECHNOLOGY";
			break;
		case "09":
			oMjCode = "ADMINISTRATIVE ASSISTANT";
			break;
		case "10":
			oMjCode = "ACCOUNTING ASSISTANT";
			break;
		case "11":
			oMjCode = "WELDING TECHNOLOGY";
			break;
		case "12":
			oMjCode = "AUTOMOTIVE COLLISION TECHNOLOGY";
			break;
		case "13":
			oMjCode = "AVAIATION PILOT TRAINING";
			break;
		}
		
		if (iGender.equals("M")){
			oGender = "Male";
		}
		else {
			oGender = "Female";
		}
	}
	public static void output() {
		//format
		
		//print detail line (iStudentID, oGender, oMjCode, iDonation)
		pw.format("%1s%7s%38s%-6s%20s%-31s%22s%-7s%n"," ",iStudentID, " ", oGender, " ", oMjCode, " ", iDonation); //132
	}
	public static void mjsub() {
		//add to next lvl
		cGtRecCtr += cRecCtr;
		cGtDonation += cMjDonation;
		
		oRecCtr = Integer.toString(cRecCtr);
		oMjDonation = nfc.format(cMjDonation);
		
		//print (oMjCode, oRecCtr, oMjDonation)
		pw.format("%132s%n"," ");
		pw.format("%18s%14s%-31s%14s%19s%-3s%23s%10s", " ", "Subtotal for: ", oMjCode, " ","Number of Records: ", oRecCtr, " ", oMjDonation); //132
		pw.format("%132s%n%n"," ");
		//zero out ctrs
		cMjDonation = 0;
		cRecCtr = 0;
		//reset hold 
		hMjCode = iMjCode;
	}
	public static void closing() {
		mjsub();
		gtotal();
		pw.close();
		System.out.println("Success! Please look at 'subtotal.prt' for results");
	}
	public static void gtotal() {
		//format
		oGtRecCtr = Integer.toString(cGtRecCtr);
		oGtDonation = nfc.format(cGtDonation);
		
		//print (oGtRecCtr, oGtDonation)
		pw.format("%132s%n"," ");
		pw.format("%18s%12s%46s%20s%-3s%22s%-12s", " ", "Grandtotals:"," ","Number of Students: ", oGtRecCtr, " ", oGtDonation); //132
		
	}
	public static void heading() {
		//print company program title
		pw.format("%30s%29s%15s%42s%6s%10s%n%n","Indian Hills Community College", " ", "Subtotal Report", " ", "Date: ", iDate); //132
		pw.format("%10s %34s %6s %31s %5s %32s %8s %n%n", "Student ID", " ", "Gender", " ", "Major", " ", "Donation"); //132
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
