/* Created by Brad Klucas 
 * Compiled on 2/7/19
 * 
 * this programs reads in an input file and prints out the valid records and 
 * separates out the errors by printing them to another file.
 * 
 * This program used validation, hard-coded arrays and regular arrays 
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PopSalesArray {
	//hard-coded error msg array
	static String[] arrErrMsg = {
			"Last name cannot be empty", 	//0
			"First name cannot be empty", 	//1
			"Address cannot be empty",		//2
			"City cannot be empty",			//3
			"State must be one of the following: 'IA', 'IL', 'MI', 'MO', 'NE' OR 'WI'", //4
			"Zip must be numeric", 			//5
			"Pop type must be numeric",		//6
			"Pop type must be between 1 and 6",		//7
			"Amount of cases must be numeric",		//8
			"Amount of cases must be greater than 1",	//9
			"Team name must be one of the following: 'A', 'B', 'C', 'D' OR 'E'"  //10
	};
	//hard-coded array for pop name
	static String[] arrPopName = {
			"Coke",
			"Diet Coke",
			"Mello Yello",
			"Cherry Coke",
			"Diet Cherry Coke",
			"Sprite"
	};
	//hard-coded array for state
	static String[] arrState = {
			"IA",
			"IL",
			"MI",
			"MO",
			"NE",
			"WI"
	};
	//hard-coded array for state deposit
	static double[] arrDeposit = {
			.05,
			.05,
			.05,
			.10,
			0,
			0
	};
	//hard-coded array for team names
	static String[] arrTeam = {
			"A",
			"B",
			"C",
			"D",
			"E"
	};
	//array for pop accumulator
	static int[] arrPopCaseCtr = new int[6];
	
	//array for team accumulator
	static double[] arrTeamTotSales = new double[5];
	
	//input from record
	static String iLName, iFName, iAddress, iCity, iState, iRecord,
					iTeam, iString;
	static int iZip, iPopType, iNumCases;
	//calc output to file
	static String oDeposit, oTotSales;
	
	//calculation
	static double cDeposit, cTotSales, cBottles;
	static int popIndex, teamIndex;
	
	//program variables
	static boolean eof = false, errSw = true;
	
	static Scanner importScan;
	static PrintWriter pw, pwErr;
	static NumberFormat nfc;
	static LocalDate today = LocalDate.now();
	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static String iDate = today.format(dtf);
	
	public static void main(String [] args) {
		init();
		do {
			valid();
			calc();
			output();
			read();
		}while (!eof);
		grandtotals();
		pw.close();
		pwErr.close();
		System.out.print("Program Executed!");
	}
	
	public static void init() {
		
		nfc = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		//set up inputScan and Error message
		try {
			importScan = new Scanner(new File("POP.dat"));
			importScan.useDelimiter(System.getProperty("line.separator"));
			
		}catch (FileNotFoundException e1) {
			System.out.println("File Error");
			System.exit(1);
		}
		//initialize JAVPOPSLB.PRT PrintWriter
		try {
			pw = new PrintWriter(new File ("JAVPOPSLB.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("VALID Output file error");
		}
		
		//initialize JAVPOPERB.PRT PrintWriter
		try {
			pwErr = new PrintWriter(new File ("JAVPOPERB.prt"));
		} catch (FileNotFoundException e) {
			System.out.println("ERROR Output file error");
		}
							
		//initialize pop case array
		importScan = new Scanner(System.in);
		for(int i = 0; i < 6; i++) {
			arrPopCaseCtr[i] = 0;
		}
		
		//initialize team total sold
		importScan = new Scanner(System.in);
		for(int i = 0; i < 5; i++) {
			arrTeamTotSales[i] = 0;
		}
		
		errHeadings();
		headings();
		read();
		valid();
	}
	
	public static void read() {
		String record;
		
		if (importScan.hasNext()) {
			record = importScan.next();
			iRecord = record;
			
			iLName = record.substring(0,15);	    //file position 1 - 15
			
			iFName = record.substring(15,30);  		//file position 16 - 30
			
			iAddress = record.substring(30,45);	    //file position 31 - 45
			
			iCity = record.substring(45,55);		//file position 46 - 55
			
			iState = record.substring(55,57);		//file position 56 - 57
			
			try {
				iString = record.substring(57,66);	//file position 58 - 66
				iZip = Integer.parseInt(iString);
			}catch(Exception e){
				pwErr.format("%-71s%5s%56s%n", record, " ", arrErrMsg[5]);
			};
			
			
			try {
				iString = record.substring(66,69);	//file position 67 - 69
				iPopType = Integer.parseInt(iString);
			}catch(Exception e) {
				pwErr.format("%-71s%5s%56s%n", record, " ", arrErrMsg[6]);
			};
			
			try { 								
				iString = record.substring(69,71);	//file position 70 - 71
				iNumCases = Integer.parseInt(iString);
			}catch(Exception e){
				pwErr.format("%-71s%5s%56s%n", record, " ", arrErrMsg[8]);
			}
			
			
			iTeam = record.substring(71,72);		//file position 72 - 72
		}
		else {
			eof = true;	
		}
		
	}
	
	public static void valid() {
		errSw = true;
		do {
			if(iLName.trim().isEmpty()){
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[0]);
				return;
				
			}
			if(iFName.trim().isEmpty()) {
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[1]);
				return;
			}
			if(iAddress.trim().isEmpty()) {
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[2]);
				return;
			}
			if(iCity.trim().isEmpty()) {
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[3]);
				return;
			}
			for(int i = 0; i>5; i+=1) {
				if(iState.equals(arrState[i])) {
					break;
				}
				else if(i==6){
					pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[4]);
					return;
				}
			}
			if(iPopType <1 || iPopType >6) {
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[7]);
				return;
			}else {
				popIndex = iPopType-1; //set index for pop calculations
			}
			if(iNumCases <1) {
				pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[9]);
				return;
			}
			for(int i = 0; i>4; i+=1) {
				if(iTeam.toUpperCase().equals(arrTeam[i])) {
					teamIndex = i; //set index for team calculations
				}
				else if(i==5){
					pwErr.format("%-71s%5s%56s%n", iRecord, " ", arrErrMsg[10]);
					return;
				}
			}
			
			errSw = false;
		}while(errSw = true);
		
	}
	
	public static void calc() {
		
		if (errSw = false) {
			cBottles = 24*iNumCases;
			for(int i = 0; i>2; i+=1) {
				if(iState.equals(arrState[i])) {
					cDeposit = cBottles * arrDeposit[i];
					break;
				}
			}
			for(int i = 3; i>3; i+=1) {
				if(iState.equals(arrState[i])) {
					cDeposit = cBottles * arrDeposit[i];
					break;
				}
			}
			for(int i = 4; i>5; i+=1) {
				if(iState.equals(arrState[i])) {
					cDeposit = 0;
					break;
				}
			}
			
			arrPopCaseCtr[popIndex] += iNumCases;
				 
			cTotSales = (18.71*iNumCases) + cDeposit;
			arrTeamTotSales[teamIndex] += cTotSales;			
		}
	}
	
	public static void output() {
		
		oDeposit = nfc.format(cDeposit);
		oTotSales = nfc.format(cTotSales);
		
		//print detail line
		pw.format("%-71s%5s%56s%n", " ", iLName, " ", iFName, " ", iCity, " ", iState, " ", iZip, " ", 
				arrPopName[popIndex], " ", iNumCases, " ", oDeposit, " ", oTotSales, " ");
	}
	
	public static void headings() {
		//print headings
		pw.format("%6s%10s%36s%28s%52s%n","Date: ", iDate, " ", "Albia Soccer Club Fundraiser", " "); //132
		pw.format("%13s%46s%15s%58s%n","PopSalesArray", " ", "Klucas Division", " "); //132
		pw.format("%60s%12s%60s%n", " ", "Sales Report", " "); //132
		pw.format("%3s%9s%8s%10s%7s%4s%8s%5s%1s%3s%1s%4s%4s%8s%13s%8s%6s%11s%6s%11s%3s%n%n",
				" ", "Last Name", " ", "First Name", " ", "City", " ", "State", " ", "Zip", " ", "Code", " ",
				"Pop Type", " ", "Quantity", " ", "Deposit Amt", " ", "Total Sales", " "); //132
	}
	
	public static void errHeadings() {
		pw.format("%30s%29s%15s%42s%6s%10s%n%n","Indian Hills Community College", " ", "Subtotal Report", " ", "Date: ", iDate); //132
		pw.format("%10s %34s %6s %31s %5s %32s %8s %n%n", "Student ID", " ", "Gender", " ", "Major", " ", "Donation"); //132
	}
	
	public static void grandtotals() {
		pw.format("%132s", " ");
		pw.format("%132s", " ");
		pw.format("%132s", " ");
		pw.format("%132s", " ");
		headings();
		pw.format("%132s", " ");
		pw.format("%13s%119s%n%n", "Grand Totals:", " "); //132
		for(int i = 0; i>2; i+=1) {
			pw.format("%6s %16s %1s %7s", " ", arrPopName[i], " ", arrPopCaseCtr[i]); //132
		}
		pw.format("%132s", " ");
		for(int i = 3; i>5; i+=1) {
			pw.format("%6s %16s %1s %7s", " ", arrPopName[i], " ", arrPopCaseCtr[i]); //132
		}
		pw.format("%132s", " ");
		pw.format("%132s", " ");
		
		pw.format("%12s%119s%n%n", "Team Totals:", " "); //132
		for(int i = 0; i>4; i+=1) {
			pw.format("%6s%1s%1s%18s%n%n", " ", arrTeam[i], " ", arrTeamTotSales[i]); //132
		}
		
	}
	
}
